<div id="footer_img"><img src="hinh/logo.png"/></div>
            <div id="footer_cont">
            	<div id="footer_cont_title"> MỸ PHẨM HANDMADE</div>
                <ul>
                	<li><img src="hinh/check.jpeg"/> Website : www.myphamhandmade.cf </li>
                    <li> <img src="hinh/check.jpeg"/> Fanpage : facebook.com/botkanshop
                    <li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Shop ngũ cốc, bột dưỡng da thiên nhiên)                    </li>
                    <li><img src="hinh/check.jpeg"/> Email : myphamhandmade1223@gmail.com</li>
                    <li><img src="hinh/check.jpeg"> Điện thoại : 0984.847.353</li>
                    <li><img src="hinh/check.jpeg" /> Địa chỉ : 243/24A Phan Đình Phùng, Phường 15, Quận Phú Nhuận, TP.Hồ Chí Minh</li>
                </ul>
            </div>
            <div id="footer_right">
           	 <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fbotkanshop&tabs=timeline&width=300&height=200&small_header=false&adapt_container_width=true&hide_cover=true&show_facepile=true&appId" width="300" height="200" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
            </div>
         <!--  <script lang="javascript"> (function() { var c = document.createElement('script'); c.type = 'text/javascript'; c.async=1; c.src = "https://my.alohihi.com/api/chat/code/4Bdm8f8hW5QQr0QlvIcA3RTlK.js"; var s = document.getElementsByTagName('script'); s[0].parentNode.insertBefore(c, s[0]); })(); </script> -