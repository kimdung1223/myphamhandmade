<ul>
                <li><a href="index.php"><img src="hinh/home.png"/>&nbsp;&nbsp;Trang chủ</a></li>
                <li><a href="introduce.php"><img src="hinh/intr.png" width="16" height="16" />&nbsp;&nbsp;Giới thiệu</a></li>
                <li><a href="deal.php" ><img src="hinh/favs.png"/>&nbsp;&nbsp;Khuyến mãi</a></li>
                <li><a href="news.php" ><img src="hinh/news.png" width="16" height="16" />&nbsp;&nbsp;Tin tức</a></li>
                <li><a href="payment.php" ><img src="hinh/icons_creditcards.png" width="16" height="16" />&nbsp;&nbsp;Thanh toán</a></li>
                <li><a href="contact.php"><img src="hinh/contact.png" width="16" height="16"/>&nbsp;&nbsp;Liên hệ</a></li>
            </ul>