<div id="left_top">
                    <div class="left_title">Danh mục sản phẩm</div>
                    <div class="lmenu1"><a href="bot.php"><img src="hinh/checked.png"/>&nbsp;&nbsp; Bột dưỡng da thiên nhiên</a></div>
                    <div class="lmenu2"><a href="dauduong.php"><img src="hinh/checked.png"/>&nbsp;&nbsp; Dầu dưỡng - Tinh dầu</a></div>
                    <div class="lmenu1"><a href="mas.php"><img src="hinh/checked.png"/>&nbsp;&nbsp; Mascara - Bi lăn</a></div>
                    <div class="lmenu2"><a href="son.php"><img src="hinh/checked.png"/>&nbsp;&nbsp;Son handmade - Tẩy tế bào</a></div>
                    <div class="lmenu1"><a href="xaphong.php"><img src="hinh/checked.png"/>&nbsp;&nbsp; Xà phòng</a></div>
                    <div class="lmenu2"><a href="khac.php"><img src="hinh/checked.png"/>&nbsp;&nbsp; Sản phẩm khác</a></div>
              </div>
                 <div id="left_right">
                 	<div class="left_title">Tin tức</div>
                     <div class="news_cont">
                	 	<a href="news1.php">
                     		<font class="title">***LÀM ĐẸP TỪ THIÊN NHIÊN***</font>      
                     		<img src="hinh/dong-y.jpg" width="160" height="160" />            
               		 	 </a>
            		 </div>
            		 <hr/>
       	   			 <div class="news_cont">
                		<a href="new2.php">
                    		<font class="title">ƯU ĐIỂM MỸ PHẨM TỰ NHIÊN</font>
                    		<img src="hinh/sudung.jpg" width="160" height="160" />
                		</a>
           			 </div>  
                 </div>