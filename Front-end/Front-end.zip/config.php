<?php
define("HOST", "localhost");
define("USER", "root");
define("PASS", "");
define("DB", "web");
define("ROOT", dirname(__FILE__));
define("BASE_URL", "http://localhost/Back-end/");