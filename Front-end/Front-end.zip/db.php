<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
define("HOST", "localhost");
define("DB_NAME","id3880554_web");
define("DB_USER", "id3880554_root");
define("DB_PASS", "123456");
//define("DB", "web");
define("ROOT",dirname(dirname(__FILE__)));
define("BASE_URL","https://myphamhandmade.cf/";
$dsn = "mysql:host=" .HOST."; dbname=". DB;
		try
		{
		$this->conn = new PDO( $dsn, USER, PASS);
		$this->conn->query("set names 'utf8' ");	
		}
		catch(Exception $e)
		{
		   echo 'Lỗi: '. $e->getMessage();
		   exit;
		}
?>
</body>
</html>