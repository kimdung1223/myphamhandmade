<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
 <?php
        include "config.php";
        include "autoload.php";
        $obj = new sanpham();
        ?>
        <form action="timsp.php" method="post">
        <table  align="center">
        &nbsp;&nbsp; <input type="text" name="tsp" placeholder="Tìm sản phẩm"/>&nbsp;&nbsp;
        <input type="submit" name="search" value="Tìm" />
        </table>
        </form>
        </fieldset>

        <?php
        if (!isset($_POST["search"]))
        {
            $data = $obj->getAll();
        }
        else
        {
            $data = $obj->search($_POST["tsp"]);
        }
		?>
</body>
</html>