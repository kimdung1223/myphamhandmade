<?php
include "config.php";
include "autoload.php";
$obj = new phieunhap();
$o2 = new nhanvien();
//print_r($_POST);
if (isset($_POST['Submit']))
{
	$mapn=$_POST['mapn'];
	$manv=$_POST['manv'];
	$ngay=$_POST['ngay'];
	//$tien=$_POST['tongtien'];
	$data = $obj->insert($mapn,$manv,$ngay,null);
	
}
$data = $obj->getAll();
$a= $o2->getAll();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Loại sản phẩm</title>
<link rel="stylesheet" href="css/form.css"/>
<link rel="stylesheet" href="css/main.css"/>
</head>

<body>
<div id="container">
    	<div id="header">
        	<div id="top">
            	<b> Xin chào admin</b>&nbsp;&nbsp;
                <img src="hinh/login.PNG"/>&nbsp;<a href="#">Đăng xuất</a>
            </div>
            <div style="clear:both"></div>
        	<div id="banner"></div>
        </div>
        <div id="menu">
        	<ul>
            	<li><a href="timloaisanpham.php">Loại sản phẩm</a></li> 
                <li><a href="timsanpham.php">Sản phẩm</a></li>
                <li><a href="timnhanvien.php">Nhân viên</a></li>
                <li><a href="timkhachhang.php">Khách hàng</a></li>
                <li><a href="timdonhang.php">Đơn hàng</a></li>
                <li><a href="#">Phiếu nhập / xuất</a>
                	<ul class="sub">
                    	<li><a href="timphieunhap.php">Phiếu nhập</a></li>
                        <li><a href="timphieuxuat.php">Phiếu xuất</a></li>
                    </ul>
                </li>
                <li><a href="timkhuyenmai.php">Khuyến mãi</a></li>
                <li><a href="timtintuc.php">Tin tức</a></li>
                <li><a href="timphanhoi.php">Phản hồi</a></li>
                <li><a href="timbinhluansp.php">Bình luận</a>  </li>
                </li>
        	</ul>
        </div>
        <div id="main">
        	<div id="main_top">
            	
            </div>
            <div id="main_bottom">
            
            </div>
        </div>
    </div>
<fieldset>
<form action="timloaisanpham.php" method="post" enctype="multipart/form-data">
<table class="tb" align="center">
    <tr>
        <td><input type="text" name="ts" placeholder="Nhập tên loại sản phẩm muốn tìm"/></td>
        <td> <input type="submit" name="search" value="Tìm" /></td>
    </tr>
</table>
</form>
</fieldset>
<br />
<?php
        if (!isset($_POST["search"]))
        {
            $data = $obj->getAll();
        }
        else
        {
            $data = $obj->search($_POST["ts"]);
        }
        ?>
<table class="tb" align="center">
<thead>
<tr>
	<th> Mã loại</th>
    <th> Tên loại</th>
    <th> Thao tác</th>
</tr>
</thead>
<?php
foreach($data as $r)
{ ?>
    <tr>
    	<td> <?php echo $r["maloaisp"]; ?></td><!-- tên bảng-->
        <td><?php echo $r["tenloaisp"]; ?></td>
        <td>
        <a href="xoaloaisanpham.php?maloai=<?php echo $r["maloaisp"]; ?>">Xóa</a> &nbsp;
        <a href="sualoaisanpham.php?maloai=<?php echo $r["maloaisp"]; ?>">Sửa</a>
        </td>
    </tr>
    <?php
}
?>
</table>
</body>
</html>