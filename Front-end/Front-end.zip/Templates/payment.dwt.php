<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- TemplateBeginEditable name="doctitle" -->
<title>MỸ PHẨM THIÊN NHIÊN</title>
<!-- TemplateEndEditable -->
<link rel="stylesheet" href="../css/main.css" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- TemplateBeginEditable name="head" -->
<!-- TemplateEndEditable -->
</head>

<body>
	<div id="container">
    	<div id="header">
        	<?php include('../include/header.php'); ?> 
        </div>
        <div id="menu">
        	<?php include('../include/menu.php'); ?>
        </div>
        <div id="main">
        	<div class="left">
            	<?php include('../include/left.php'); ?>
            </div>
            <div class="content"><!-- TemplateBeginEditable name="EditRegion1" -->
             <div id="cont_title">HƯỚNG DẪN CÁCH MUA HÀNG<br/>
               		 <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Ffacebook.com%2Fbotkanshop&layout=button&size=small&mobile_iframe=true&width=67&height=20&appId" width="67" height="20" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe></div>
              <div>
              	<p>
                	<b>1. Mua hàng trực tiếp tại cửa hàng: </b><br/>
                   	   - Địa chỉ : 243/24A Phan Đình Phùng, P.15, Q.Phú Nhuận.<br/>
                       - ĐT : 0984 847 35<br/>
              	    <b>2. Ship COD - Nhận hàng và thu tiền tận nơi:</b><br/>
                       - Áp dụng cho khu vực nội và ngoại thành TP.HCM.<br/>
                       - Bảng giá ship<br/>
                     	  + Nội thành : 5K - 40K<br/>
                     	  + Ngoại thành( Quận 9, 12, Thủ Đức, Bình Tân, Hóc Môn , Nhà Bè, Bình Chánh, Cần Giờ ) <br/>
                   <b>3. Thanh toán chuyển khoản:</b><br/>
                       - Áp dụng với khách tỉnh, khách sỉ và khách mua hàng trực tuyến.
                       - Thông tin tài khoản: <br/>
                    	  + Viettinbank chi nhánh Phú Nhuận <br/>
                          + Số TK: 103866726008<br/>
                          + Chủ tài khoản : Lê Huỳnh Kim Dung
                    
                </p>
              </div>
            <!-- TemplateEndEditable -->
            	
            </div>
            <div style="clear:both"></div>
        </div>
      <div id="footer">
        	<?php include('../include/footer.php'); ?>
      </div>
    </div>
</body>
</html>
