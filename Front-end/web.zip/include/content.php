<div id="content_top">
                	 <marquee direction="right" width="100%">
                		<div align="center">
                            <img class="slide" src="hinh/logo.png" height="150" />
                            <img class="slide" src="hinh/chamsocda.jpg" height="150"/>
                            <img class="slide"src="hinh/xaphong.jpg" height="150"/>
                            <img class="slide" src="hinh/bottraxanh.jpg" height="150"/>
                            <img class="slide" src="hinh/sp/dầu dưỡng/dauolive.jpg" height="150"/>
                            <img class="slide"  src="hinh/tinhdaulavender.jpg" height="150"/>
                            <img class="slide" src="hinh/sonhandmade.jpg" height="150"/>
                            <img class="slide" src="hinh/sp/dầu dưỡng/daujojoba.jpg"height="150"/>
                            <img class="slide" src="hinh/mypham.jpg" height="150" />
                            <img class="slide" src="hinh/dau.jpg"height="150" />
                	    </div>
                     </marquee>
               </div>
               <div style="clear:both"></div>
               <div id="content_bottom">
					<div id="cont_pro_title">SẢN PHẨM</div>
                    <div id="content_pro">
                    	<div class="product_box">
                			<div class="pro_box_top"></div>
                    		<div class="pro_box_mid">
                        	<div class="pro_title">Bột dưỡng da thiên nhiên</div>
                        	<div class="pro_img"><a href="bot.php"><img src="hinh/bottraxanh.jpg" /></a></div>
                            <div class="pro_detail"><a href="bot.php">Xem thêm </a></div>
                        	<div style="clear:both"></div>
                    	</div>
                   		 	<div class="pro_box_bot"></div>
               		   </div>
                       <div class="product_box">
                			<div class="pro_box_top"></div>
                    		<div class="pro_box_mid">
                        	<div class="pro_title">Dầu dưỡng - Tinh dầu</div>
                        	<div class="pro_img"><a href="dauduong.php"><img src="hinh/dauhanhnhan.jpg" /></a></div>
                            <div class="pro_detail"><a href="dauduong.php">Xem thêm </a></div>
                        	<div style="clear:both"></div>
                    	</div>
                   		 	<div class="pro_box_bot"></div>
               		   </div>
                       <div class="product_box">
                			<div class="pro_box_top"></div>
                    		<div class="pro_box_mid">
                        	<div class="pro_title">Mascara - Bi lăn</div>
                        	<div class="pro_img"><a href="mas.php"><img src="hinh/masbi.JPG" /></a></div>
                            <div class="pro_detail"><a href="mas.php">Xem thêm </a></div>
                        	<div style="clear:both"></div>
                    	</div>
                   		 	<div class="pro_box_bot"></div>
               		   </div>
                    </div>
                    <div style="clear:both"></div>
                     <div id="content_pro">
                    	<div class="product_box">
                			<div class="pro_box_top"></div>
                    		<div class="pro_box_mid">
                        	<div class="pro_title">Son handmade - Tẩy tế bào</div>
                        	<div class="pro_img"><a href="son.php"><img src="hinh/sonkem.jpg" /></a></div>
                            <div class="pro_detail"><a href="son.php">Xem thêm </a></div>
                        	<div style="clear:both"></div>
                    	</div>
                   		 	<div class="pro_box_bot"></div>
               		   </div>
                       <div class="product_box">
                			<div class="pro_box_top"></div>
                    		<div class="pro_box_mid">
                        	<div class="pro_title">Xà phòng</div>
                        	<div class="pro_img"><a href="xaphong.php"><img src="hinh/xaphonghandmade.jpg" /></a></div>
                            <div class="pro_detail"><a href="xaphong.php">Xem thêm </a></div>
                        	<div style="clear:both"></div>
                    	</div>
                   		 	<div class="pro_box_bot"></div>
               		   </div>
                       <div class="product_box">
                			<div class="pro_box_top"></div>
                    		<div class="pro_box_mid">
                        	<div class="pro_title">Sản phẩm khác</div>
                        	<div class="pro_img"><a href="khac.php"><img src="hinh/dungcu.jpg" width="153" /></a></div>
                            <div class="pro_detail"><a href="khac.php">Xem thêm </a></div>
                        	<div style="clear:both"></div>
                    	</div>
                   		 	<div class="pro_box_bot"></div>
               		   </div>
                    </div>
                    </div>