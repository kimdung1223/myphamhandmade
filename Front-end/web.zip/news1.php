<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/news1.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>MỸ PHẨM THIÊN NHIÊN</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" href="css/main.css" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<style type="text/css">
#js_6 img
{
	font-size:16px;
}
</style><!-- InstanceBeginEditable name="head" -->
<!-- InstanceEndEditable -->
</head>

<body>
	<div id="container">
    	<div id="header">
        	<?php include('include/header.php'); ?> 
        </div>
        <div id="menu">
        	<?php include('include/menu.php'); ?>
        </div>
        <div id="main">
        	<div class="left">
            	<?php include('include/left.php'); ?>
            </div>
            <div class="content"><!-- InstanceBeginEditable name="EditRegion1" -->
            
            </p>
            <p>Bạn đang dùng các loại hóa mỹ phẩm hoặc uống nhiều thuốc giảm cân mắc tiền nhưng vẫn cảm thấy lo lắng, không an tâm và không mang đến sự hài lòng về sản phẩm <img aria-hidden="1" height="16" src="https://www.facebook.com/images/emoji.php/v8/f95/1/16/1f629.png" width="16" alt="" /><img aria-hidden="1" height="16" src="https://www.facebook.com/images/emoji.php/v8/f95/1/16/1f629.png" width="16" alt="" /><img aria-hidden="1" height="16" src="https://www.facebook.com/images/emoji.php/v8/f95/1/16/1f629.png" width="16" alt="" /> <br />
                Hãy thử SẢN PHẨM TỪ THIÊN NHIÊN, tại sao không<img aria-hidden="1" height="16" src="https://www.facebook.com/images/emoji.php/v8/f4c/1/16/2753.png" width="16" alt="" /><br />
  <img aria-hidden="1" height="16" src="https://www.facebook.com/images/emoji.php/v8/ffc/1/16/1f44d.png" width="16" alt="" /> Sản phẩm hoàn toàn tự nhiên, 100% nguyên chất, không pha bất kỳ tạp chất hay dùng chất bảo quản nên đảm bảo an toàn - hiệu quả khi sử dụng<br />
  <img aria-hidden="1" height="16" src="https://www.facebook.com/images/emoji.php/v8/ffc/1/16/1f44d.png" width="16" alt="" /> Gần như không có tác dụng phụ, ít gây kích ứng da<br />
  <img aria-hidden="1" height="16" src="https://www.facebook.com/images/emoji.php/v8/ffc/1/16/1f44d.png" width="16" alt="" /> Dưỡng da khỏe, đẹp từ sâu bên trong<br />
  <img aria-hidden="1" height="16" src="https://www.facebook.com/images/emoji.php/v8/ffc/1/16/1f44d.png" width="16" alt="" /> Kiên trì sử dụng để đạt được kết quả như mong muốn<br />
  <img aria-hidden="1" height="16" src="https://www.facebook.com/images/emoji.php/v8/ffc/1/16/1f44d.png" width="16" alt="" /> Không bị lệ thuộc vào sản phẩm khi ngừng dùng <br />
                ------------------------------------------------------------<br />
  <img aria-hidden="1" height="16" src="https://www.facebook.com/images/emoji.php/v8/fa9/1/16/1f353.png" width="16" alt="" /> BỘT DƯỠNG DA TỪ THIÊN NHIÊN có nhiều công dụng tuyệt vời như trị mụn, giảm nhờn, xóa mờ vết thâm nám, ngăn ngừa nếp nhăn, tái tạo làn da, se khít lỗ chân lông, dưỡng ẩm, chống lại tia UV có hại,.... tùy thuộc vào từng loại sản phẩm.<br />
  <img aria-hidden="1" height="16" src="https://www.facebook.com/images/emoji.php/v8/f8f/1/16/1f348.png" width="16" alt="" /> SON HANDMADE - TẨY TẾ BÀO với các thành phần chủ yếu dành cho dưỡng môi giúp bạn sở hữu <img aria-hidden="1" height="16" src="https://www.facebook.com/images/emoji.php/v8/fcc/1/16/1f444.png" width="16" alt="" /> hồng hào, tươi tắn, rạng rỡ <img aria-hidden="1" height="16" src="https://www.facebook.com/images/emoji.php/v8/f68/1/16/1f495.png" width="16" alt="" /> Phù hợp với nhiều đối tượng <img aria-hidden="1" height="16" src="https://www.facebook.com/images/emoji.php/v8/ffe/1/16/1f44f.png" width="16" alt="" /><img aria-hidden="1" height="16" src="https://www.facebook.com/images/emoji.php/v8/ffe/1/16/1f44f.png" width="16" alt="" /><img aria-hidden="1" height="16" src="https://www.facebook.com/images/emoji.php/v8/ffe/1/16/1f44f.png" width="16" alt="" /><br />
  <img aria-hidden="1" height="16" src="https://www.facebook.com/images/emoji.php/v8/f38/1/16/1f34a.png" width="16" alt="" /> MASCARA - BI LĂN có công dụng dưỡng mi dài và dày, dưỡng môi không bị khô.<br />
  <img aria-hidden="1" height="16" src="https://www.facebook.com/images/emoji.php/v8/fe/1/16/1f347.png" width="16" alt="" />  XÀ PHÒNG không chỉ giúp bạn làm sạch cơ thể mà còn giúp bạn sở hữu làn da trắng - đều màu hơn, bảo vệ da khi tiếp xúc với ánh nắng mặt trời, cung cấp độ ẩm và cân bằng độ PH mang đến làn da tươi tắn, khỏe khoắn.<br />
  <img aria-hidden="1" height="16" src="https://www.facebook.com/images/emoji.php/v8/fbb/1/16/1f34d.png" width="16" alt="" /> DẦU DƯỠNG - TINH DẦU là dược phẩm tự nhiên với nhiều tác dụng: dưỡng da, dưỡng mi, dưỡng môi, dưỡng tóc,...giúp bạn sở hữu vẻ đẹp tự nhiên.<br />
  <img aria-hidden="1" height="16" src="https://www.facebook.com/images/emoji.php/v8/f6d/1/16/2600.png" width="16" alt="" />☀ LÀM ĐẸP TỪ THIÊN NHIÊN AN TOÀN HIỆU QUẢ <img aria-hidden="1" height="16" src=
 "https://www.facebook.com/images/emoji.php/v8/fe9/1/16/1f496.png" width="16" alt="" /></p>
            <!-- InstanceEndEditable -->
            	
            </div>
            <div style="clear:both"></div>
        </div>
      <div id="footer">
        	<?php include('include/footer.php'); ?>
      </div>
    </div>
</body>
<!-- InstanceEnd --></html>
